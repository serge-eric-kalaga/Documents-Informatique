Calculatrice simple-------------------
Url     : http://codes-sources.commentcamarche.net/source/38287-calculatrice-simpleAuteur  : nexan44Date    : 02/08/2013
Licence :
=========

Ce document intitul� � Calculatrice simple � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Je sais qu'il y a d&eacute;ja des srcipts pour la calculatrice mais celle-ci est
 plus simple et on peut l'ouvrir dans une pop-up (pour que le visiteur ait toujo
urs la calculatrice sous la main).
<br />
<br />Vous devez cr&eacute;er deux p
ages, une pour la calculatrice (page 1) et l'autre pour ouvrir cet page dans une
 pop-up (page 2).
<br /><a name='source-exemple'></a><h2> Source / Exemple : </
h2>
<br /><pre class='code' data-mode='basic'>
// PAGE 1 ! 

&lt;html&gt;

&lt;head&gt;
&lt;title&gt;Calculatrice Simple&lt;/title&gt;

&lt;script langu
age=&quot;JavaScript&quot;&gt;

function verification(entree) {
  var car =&q
uot;1234567890[]()+-.*,/&quot;;
  for (var i = 0; i &lt; entree.length; i++)
 
  if (car.indexOf(entree.charAt(i))&lt;0 ) return false;
  return true;
 }


 function calcul() {
   var a = 0;
  if (verification(window.document.calculat
rice.result.value))
     a = eval(window.document.calculatrice.result.value);

   window.document.calculatrice.result.value = a;
 }

 function ajouter(carac
teres) {
   window.document.calculatrice.result.value =
   window.document.cal
culatrice.result.value + caracteres;
 }

 function fonction_speciale(fonction
) {
   if (verification(window.document.calculatrice.result.value)) {
     if(
fonction == &quot;sqrt&quot;) {
       var a = 0;
     a = eval(window.documen
t.calculatrice.result.value);
     window.document.calculatrice.result.value = 
Math.sqrt(a);
   }
   if(fonction == &quot;pow&quot;) {
     var a = 0;
    
 a = eval(window.document.calculatrice.result.value);
     window.document.calc
ulatrice.result.value = a * a;
   }
   if(fonction == &quot;log&quot;) {
    
 var a = 0;
     a = eval(window.document.calculatrice.result.value);
     win
dow.document.calculatrice.result.value = Math.log(a);
   }
  } else window.doc
ument.calculatrice.result.value = 0
}

&lt;/script&gt;
&lt;/head&gt;
&lt;bo
dy&gt;
&lt;table border bgcolor=#0001cc&gt;
&lt;th&gt;
&lt;form name=&quot;ca
lculatrice&quot;&gt;
&lt;center&gt;
&lt;textarea style=&quot;WIDTH: 186px; HEI
GHT: 24px; TEXT-ALIGN:right;&quot; name=&quot;result&quot; align=&quot;right&quo
t; class=&quot;affiche&quot;&gt;&lt;/textarea&gt;&lt;br&gt;
&lt;input style=&qu
ot;FONT-WEIGHT: bold; WIDTH: 44px; HEIGHT: 24px&quot; type=&quot;button&quot; na
me=&quot;b2&quot; value=&quot;7&quot; onClick=&quot;ajouter('7')&quot; size=&quo
t;30&quot;&gt;
&lt;input style=&quot;FONT-WEIGHT: bold; WIDTH: 44px; HEIGHT: 24
px&quot; type=&quot;button&quot; name=&quot;b3&quot; value=&quot;8&quot; onClick
=&quot;ajouter('8')&quot; size=&quot;30&quot;&gt;
&lt;input style=&quot;FONT-WE
IGHT: bold; WIDTH: 44px; HEIGHT: 24px&quot; type=&quot;button&quot; name=&quot;b
4&quot; value=&quot;9&quot; onClick=&quot;ajouter('9')&quot; size=&quot;30&quot;
&gt;
&lt;input style=&quot;FONT-WEIGHT: bold; WIDTH: 44px; HEIGHT: 24px&quot; t
ype=&quot;button&quot; name=&quot;b12&quot; value=&quot;:&quot; onClick=&quot;aj
outer('/')&quot; size=&quot;30&quot;&gt;&lt;br&gt;
&lt;input style=&quot;FONT-W
EIGHT: bold; WIDTH: 44px; HEIGHT: 24px&quot; type=&quot;button&quot; name=&quot;
b5&quot; value=&quot;4&quot; onClick=&quot;ajouter('4')&quot; size=&quot;30&quot
;&gt;
&lt;input style=&quot;FONT-WEIGHT: bold; WIDTH: 44px; HEIGHT: 24px&quot; 
type=&quot;button&quot; name=&quot;b6&quot; value=&quot;5&quot; onClick=&quot;aj
outer('5')&quot; size=&quot;30&quot;&gt;
&lt;input style=&quot;FONT-WEIGHT: bol
d; WIDTH: 44px; HEIGHT: 24px&quot; type=&quot;button&quot; name=&quot;b7&quot; v
alue=&quot;6&quot; onClick=&quot;ajouter('6')&quot; size=&quot;30&quot;&gt;
&lt
;input style=&quot;FONT-WEIGHT: bold; WIDTH: 44px; HEIGHT: 24px&quot; type=&quot
;button&quot; name=&quot;b11&quot; value=&quot;x&quot; onClick=&quot;ajouter('*'
)&quot; size=&quot;30&quot;&gt;&lt;br&gt;
&lt;input style=&quot;FONT-WEIGHT: bo
ld; WIDTH: 44px; HEIGHT: 24px&quot; type=&quot;button&quot; name=&quot;b8&quot; 
value=&quot;1&quot; onClick=&quot;ajouter('1')&quot; size=&quot;30&quot;&gt;
&l
t;input style=&quot;FONT-WEIGHT: bold; WIDTH: 44px; HEIGHT: 24px&quot; type=&quo
t;button&quot; name=&quot;b9&quot; value=&quot;2&quot; onClick=&quot;ajouter('2'
)&quot; size=&quot;30&quot;&gt;
&lt;input style=&quot;FONT-WEIGHT: bold; WIDTH:
 44px; HEIGHT: 24px&quot; type=&quot;button&quot; name=&quot;b10&quot; value=&qu
ot;3&quot; onClick=&quot;ajouter('3')&quot; size=&quot;30&quot;&gt;
&lt;input s
tyle=&quot;FONT-WEIGHT: bold; WIDTH: 44px; HEIGHT: 24px&quot; type=&quot;button&
quot; name=&quot;b13&quot; value=&quot;-&quot; onClick=&quot;ajouter('-')&quot; 
size=&quot;30&quot;&gt;&lt;br&gt;
&lt;input style=&quot;FONT-WEIGHT: bold; WIDT
H: 92px; HEIGHT: 24px&quot; type=&quot;button&quot; name=&quot;b14&quot; value=&
quot;0&quot; onClick=&quot;ajouter('0')&quot; size=&quot;30&quot;&gt;
&lt;input
 style=&quot;FONT-WEIGHT: bold; WIDTH: 44px; HEIGHT: 24px&quot; type=&quot;butto
n&quot; name=&quot;b15&quot; value=&quot;.&quot; onClick=&quot;ajouter('.')&quot
; size=&quot;30&quot;&gt;
&lt;input style=&quot;FONT-WEIGHT: bold; WIDTH: 44px;
 HEIGHT: 24px&quot; type=&quot;button&quot; name=&quot;b16&quot; value=&quot;+&q
uot; onClick=&quot;ajouter('+')&quot; size=&quot;30&quot;&gt;&lt;br&gt;
&lt;inp
ut style=&quot;FONT-WEIGHT: bold; WIDTH: 140px; HEIGHT: 24px&quot; type=&quot;re
set&quot; name=&quot;b17&quot; value=&quot;ON/C&quot; size=&quot;30&quot;&gt;
&
lt;input style=&quot;FONT-WEIGHT: bold; WIDTH: 44px; HEIGHT: 24px&quot; type=&qu
ot;button&quot; name=&quot;b18&quot; value=&quot;=&quot; onClick=&quot;calcul()&
quot; size=&quot;30&quot;&gt;&lt;br&gt;
&lt;input style=&quot;FONT-WEIGHT: bold
; WIDTH: 60px; HEIGHT: 24px&quot; type=&quot;button&quot;  class=&quot;button&qu
ot; value=&quot;sqrt &quot; onClick=&quot;fonction_speciale('sqrt')&quot;&gt;
&
lt;input style=&quot;FONT-WEIGHT: bold; WIDTH: 60px; HEIGHT: 24px&quot; type=&qu
ot;button&quot;  class=&quot;button&quot; value=&quot; pow &quot; onClick=&quot;
fonction_speciale('pow')&quot;&gt;
&lt;input style=&quot;FONT-WEIGHT: bold; WID
TH: 60px; HEIGHT: 24px&quot; type=&quot;button&quot;  class=&quot;button&quot; v
alue=&quot; log &quot; onClick=&quot;fonction_speciale('log')&quot;&gt;
&lt;/ce
nter&gt;
&lt;/form&gt;
&lt;/th&gt;
&lt;/table&gt;

&lt;/body&gt;
&lt;/html
&gt;

// PAGE 2 !

&lt;html&gt;

&lt;head&gt;
&lt;title&gt;Calculatrice S
imple&lt;/title&gt;
&lt;/head&gt;

&lt;body vlink=&quot;#0000FF&quot;&gt;


&lt;p&gt;&lt;a href=&quot;calcul.htm&quot; target=&quot;popup&quot;
onmouseover
=&quot;this.style.color='red'&quot;
onmouseout=&quot;this.style.color='blue'&qu
ot;
onclick=&quot;window.open('','popup','width=218,height=215,left=100,top=100
,resizable=no,scrollbars=no,toolbar=no,menubar=no,location=no,status=no')&quot;&
gt;Calculatrice&lt;/a&gt;
&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
<br
 /><a name='conclusion'></a><h2> Conclusion : </h2>
<br />Voil&agrave;, et pui
s regardez le fichier zip si vous ne comprennez pas ou si &ccedil;a ne marche pa
s
